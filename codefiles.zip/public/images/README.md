# Case photos

The "Before & after" section on the homepage reads its images from this folder.
Each case needs a **matching pair** — if either half is missing, that card falls
back to a "Photo pair not found" placeholder instead of showing a broken slider.

Expected filenames (see `CASES` in `src/lib/clinic.ts`):

```
case-1-before.jpg   case-1-after.jpg    Composite bonding, upper four
case-2-before.jpg   case-2-after.jpg    Professional whitening
case-3-before.jpg   case-3-after.jpg    Fixed braces, 14 months
case-4-before.jpg   case-4-after.jpg    Scaling and polishing
```

Files in `public/` are served from the site root, so `case-1-before.jpg` here is
requested as `/images/case-1-before.jpg`.

## Before you add anything

Only publish clinical photographs where the patient has signed a release
covering website use. The consent notice shown under this section states that
promise to visitors, so it has to hold.

## Shooting notes

Shoot both halves the same way or the comparison misleads: same framing,
same distance, same lighting, same retraction. Landscape 4:3 crops fit the
slider without letterboxing. Around 1200px wide is plenty.

To add, rename or remove a case, edit the `CASES` array in
`src/lib/clinic.ts` — the grid and filenames follow from it.
