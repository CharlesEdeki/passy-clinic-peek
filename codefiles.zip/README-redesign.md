# Passy Dental Clinic — homepage redesign

Ports the approved HTML design onto the repo's existing stack. Nothing in the
toolchain changed: still TanStack Start, React 19, Vite, TypeScript, Tailwind
v4, shadcn/ui, Radix, lucide-react, sonner.

## Applying it

From a clean checkout of `CharlesEdeki/passy-clinic-peek`:

```bash
git am < passy-clinic-redesign.patch   # keeps the commit message
# or, to stage the changes without committing:
git apply passy-clinic-redesign.patch
```

Then:

```bash
bun install
bun run dev
```

Verified against a fresh clone with `git apply --check`. `tsc --noEmit` is
clean and `vite build` succeeds.

## What changed

| Area | Before | After |
| --- | --- | --- |
| Palette | Navy `oklch(0.32 0.07 258)` on warm cream | Theatre green `#1F5E4E`, coral `#E5544B`, mint `#DCEDE6`, paper `#F6F7F4`, ink `#0E211C` |
| Type | Inter + JetBrains Mono | Fraunces (display) + Karla (body) + JetBrains Mono (labels) |
| Structure | One 546-line `routes/index.tsx` | 13 components under `components/site/` |
| Content | Inline in the route | `lib/clinic.ts` |
| Sections | Hero, services, about, HMO, booking, location | Hero + tooth chart, services, reviews, gallery, before/after, HMO, booking, FAQ, visit |

### New files

```
src/lib/clinic.ts                     services, reviews, FAQs, hours, contact details
src/hooks/use-reveal.ts               scroll-triggered reveal
src/hooks/use-active-section.ts       nav underline tracking
src/hooks/use-clinic-status.ts        live open/closed in Africa/Lagos
src/components/site/                  header, hero, tooth-arch, tooth-selection,
                                      services, reviews, gallery, results, hmo,
                                      booking, faq, visit, footer, whatsapp-fab,
                                      primitives
```

`src/styles.css`, `src/routes/index.tsx` and `src/routes/__root.tsx` were
rewritten. `components/GoogleReviews.tsx` moved to
`components/site/google-reviews.tsx`.

## Decisions worth knowing about

**Tokens over hardcoded colours.** The brand palette is defined once in
`:root` and mapped onto shadcn's semantic names in `@theme inline`. Every
`ui/` component picks up the brand without being touched, and a future palette
change is a handful of hex values rather than a find-and-replace.

**Hydration safety.** The design shows live opening hours, highlights today's
row, and sets a `min` on the date picker — all clock-dependent. Rendering
those during SSR would produce different markup on the server than the client
and break hydration, so they resolve in an effect. The status pill shows
"Checking hours…" for one frame, matching the original.

**A fix to the original logic.** The source showed "Closed — opens 8:00am" on
a Saturday evening, which implies Sunday. It now points at Monday.

**Repo primitives, not reimplementations.** The FAQ uses the existing Radix
Accordion (default chevron hidden in favour of the rotating plus), the booking
form uses shadcn `Input` / `Label` / `Textarea` / `Select`, the toast is
`sonner`, and icons are `lucide-react`.

**Tooth chart to booking form.** Both read the same React context
(`tooth-selection.tsx`), so selected areas are appended to the WhatsApp
message and echoed under the notes field.

**Accessibility.** Teeth are keyboard-operable buttons with `aria-pressed`;
the lightbox traps focus, restores it on close, and handles Escape and arrow
keys; the mobile drawer is `inert` when closed so off-screen links can't be
tabbed to; `prefers-reduced-motion` disables the reveal animations entirely.

## Needs your input

1. **Before/after photos.** All four cards show the "Photo pair not found"
   placeholder until pairs land in `public/images/` — same behaviour as the
   HTML. See `public/images/README.md` for filenames and the consent note.

2. **Reviews: static or live?** The HTML has three static testimonials; the
   repo had a live SociableKit widget (embed `25699874`). I built the static
   version as the visible design and kept the widget component retimed to the
   new palette (`id` changed to `google-reviews` to avoid clashing). Say which
   you want and I'll wire it in.

3. **Stale metadata.** `__root.tsx` still carries `twitter:site` of `@Lovable`
   and an `og:image` pointing at a `gpt-engineer-file-uploads` URL. Worth
   replacing with the clinic's own before launch — I left them rather than
   guess at replacements.
