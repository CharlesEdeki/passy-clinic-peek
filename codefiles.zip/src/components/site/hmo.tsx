import { Reveal } from "@/components/site/primitives";
import { HMO_PARTNERS } from "@/lib/clinic";

export function Hmo() {
  return (
    <section id="hmo" className="bg-theatre-deep py-19 text-white md:py-26">
      <div className="mx-auto max-w-[1180px] px-6">
        <Reveal>
          <span className="mb-3.5 block font-mono text-[0.72rem] uppercase tracking-[0.18em] text-[#8FD3BC]">
            Cover &amp; payment
          </span>
          <h2 className="text-[clamp(2rem,4vw,3.1rem)] text-white">Your HMO is welcome here.</h2>
          <p className="mt-5 max-w-[56ch] text-[1.05rem] text-white/70">
            Bring your enrolee ID and we&rsquo;ll verify cover before treatment begins — no surprise
            bills at the end of your visit. Not on a plan? We accept transfer, card and cash.
          </p>
        </Reveal>

        <Reveal delay={1}>
          <ul className="mt-9 flex flex-wrap gap-4">
            {HMO_PARTNERS.map((partner) => (
              <li
                key={partner}
                className="rounded-full border border-white/[0.16] bg-white/[0.08] px-6 py-3 text-[0.95rem] font-semibold"
              >
                {partner}
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </section>
  );
}
