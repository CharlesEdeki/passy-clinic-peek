import { Star } from "lucide-react";

import { Eyebrow, Reveal } from "@/components/site/primitives";
import { REVIEWS } from "@/lib/clinic";

export function Reviews() {
  return (
    <section id="reviews" className="bg-mint py-19 md:py-26">
      <div className="mx-auto max-w-[1180px] px-6">
        <Reveal>
          <Eyebrow>Patient reviews</Eyebrow>
          <h2 className="text-[clamp(2rem,4vw,3.1rem)]">
            What people say after
            <br />
            they&rsquo;ve been in.
          </h2>
        </Reveal>

        <div className="mt-13 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {REVIEWS.map((review, index) => (
            <Reveal key={review.name} delay={(index % 3) as 0 | 1 | 2} className="h-full">
              <figure className="h-full rounded-lg border border-border bg-white p-7">
                <div
                  className="mb-3.5 flex gap-0.5 text-gold"
                  role="img"
                  aria-label="Rated 5 out of 5"
                >
                  {Array.from({ length: 5 }, (_, star) => (
                    <Star key={star} className="size-4 fill-current" aria-hidden="true" />
                  ))}
                </div>
                <blockquote className="text-[0.96rem]">&ldquo;{review.quote}&rdquo;</blockquote>
                <figcaption className="mt-[18px] flex items-center gap-[11px]">
                  <span className="grid size-[38px] shrink-0 place-items-center rounded-full bg-mint text-[0.85rem] font-bold text-theatre">
                    {review.name.charAt(0)}
                  </span>
                  <span>
                    <span className="block text-[0.9rem] font-bold">{review.name}</span>
                    <span className="block text-[0.78rem] text-muted-foreground">
                      {review.area}
                    </span>
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
