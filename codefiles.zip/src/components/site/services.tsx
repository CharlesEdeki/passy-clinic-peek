import { Eyebrow, Lede, Reveal } from "@/components/site/primitives";
import { SERVICES } from "@/lib/clinic";

export function Services() {
  return (
    <section id="services" className="py-19 md:py-26">
      <div className="mx-auto max-w-[1180px] px-6">
        <Reveal>
          <Eyebrow>What we do</Eyebrow>
          <h2 className="text-[clamp(2rem,4vw,3.1rem)]">
            Everything your family&rsquo;s
            <br />
            teeth are likely to need.
          </h2>
          <Lede>
            Routine and specialist care under one roof, so you&rsquo;re not sent across Lagos for a
            referral.
          </Lede>
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service, index) => (
            <Reveal key={service.title} delay={(index % 3) as 0 | 1 | 2} className="h-full">
              <article className="h-full rounded-lg border border-border bg-white px-[26px] py-[30px] transition duration-300 hover:-translate-y-[5px] hover:border-theatre hover:shadow-[0_18px_40px_-26px_rgb(14_33_28/0.45)]">
                <span className="mb-[18px] grid size-11 place-items-center rounded-xl bg-mint">
                  <svg
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={1.7}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="size-[22px] text-theatre"
                  >
                    <path d={service.icon} />
                  </svg>
                </span>
                <h3 className="text-[1.18rem]">{service.title}</h3>
                <p className="mt-2.5 text-[0.94rem] text-muted-foreground">{service.blurb}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
