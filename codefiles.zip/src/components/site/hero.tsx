import { ToothArch } from "@/components/site/tooth-arch";
import { useClinicStatus } from "@/hooks/use-clinic-status";
import { PHONE_HREF } from "@/lib/clinic";
import { cn } from "@/lib/utils";

const TRUST = [
  { value: "12+", label: "Years in Isolo" },
  { value: "8,000+", label: "Patients seen" },
  { value: "Mon–Sat", label: "8am – 6pm" },
];

export function Hero() {
  const status = useClinicStatus();

  return (
    <div id="top" className="relative overflow-hidden pb-24 pt-[132px] md:pt-[180px]">
      {/* Mint bloom behind the headline — purely atmospheric. */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-[220px] -top-[320px] size-[760px] rounded-full opacity-85 [background:radial-gradient(circle,var(--mint),transparent_68%)]"
      />

      <div className="relative mx-auto grid max-w-[1180px] items-center gap-11 px-6 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16">
        <div>
          <p className="mb-[26px] inline-flex items-center gap-[9px] rounded-full border border-border bg-white px-4 py-2 text-[0.83rem] font-medium">
            <span
              className={cn(
                "size-2 rounded-full",
                status?.open ? "animate-pulse-ring bg-live" : "bg-coral",
              )}
            />
            {status?.label ?? "Checking hours…"}
          </p>

          <h1 className="text-[clamp(2.6rem,6vw,4.6rem)]">
            Dentistry that
            <br />
            doesn&rsquo;t make you
            <br />
            <em className="italic text-theatre">dread the chair.</em>
          </h1>

          <p className="mt-5 max-w-[56ch] text-[1.05rem] text-muted-foreground">
            A calm, modern clinic at Jakande Gate, Isolo. General care, braces, whitening and
            pediatric dentistry — with HMO enrolees welcome and same-day slots for pain.
          </p>

          <div className="mt-9 flex flex-wrap gap-3.5">
            <a
              href="#book"
              className="inline-flex items-center gap-2.5 rounded-full bg-theatre px-[26px] py-3.5 text-[0.97rem] font-semibold text-white shadow-[0_6px_20px_-8px_rgb(31_94_78/0.7)] transition-[transform,background-color] duration-200 hover:-translate-y-0.5 hover:bg-theatre-deep"
            >
              Book an appointment
            </a>
            <a
              href={PHONE_HREF}
              className="inline-flex items-center gap-2.5 rounded-full border-[1.5px] border-border px-[26px] py-3.5 text-[0.97rem] font-semibold transition-[transform,border-color,background-color] duration-200 hover:-translate-y-0.5 hover:border-theatre hover:bg-white"
            >
              Call the clinic
            </a>
          </div>

          <dl className="mt-13 flex flex-wrap gap-8 border-t border-border pt-7">
            {TRUST.map((item) => (
              <div key={item.label} className="flex flex-col">
                <dt className="font-mono text-[0.7rem] uppercase tracking-[0.13em] text-muted-foreground">
                  {item.label}
                </dt>
                <dd className="order-first font-display text-[1.7rem] leading-none">
                  {item.value}
                </dd>
              </div>
            ))}
          </dl>
        </div>

        <ToothArch />
      </div>
    </div>
  );
}
