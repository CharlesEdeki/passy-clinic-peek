import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";

import clinicDentist from "@/assets/clinic-dentist.jpg";
import clinicHero from "@/assets/clinic-hero.jpg";
import { Eyebrow, Lede, Reveal } from "@/components/site/primitives";
import { GALLERY_FILTERS, type GalleryCategory } from "@/lib/clinic";
import { cn } from "@/lib/utils";

type Photo = { kind: "photo"; src: string; category: GalleryCategory; caption: string };
type Slot = { kind: "slot"; category: GalleryCategory; title: string; note: string };
type Item = Photo | Slot;

const ITEMS: Item[] = [
  {
    kind: "photo",
    src: clinicHero,
    category: "clinic",
    caption: "Treatment room one, set up for a routine check",
  },
  {
    kind: "photo",
    src: clinicDentist,
    category: "team",
    caption: "Consultations start with a conversation, not a drill",
  },
  { kind: "slot", category: "clinic", title: "Reception", note: "Wide shot, daylight" },
  { kind: "slot", category: "equipment", title: "Sterilisation bay", note: "Autoclave in frame" },
  { kind: "slot", category: "clinic", title: "Children's corner", note: "Toys and low seating" },
  { kind: "slot", category: "equipment", title: "Intraoral camera", note: "Screen visible" },
];

export function Gallery() {
  const [filter, setFilter] = useState<GalleryCategory | "all">("all");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const lastFocused = useRef<HTMLElement | null>(null);
  const touchStartX = useRef(0);

  const visible = useMemo(
    () => ITEMS.filter((item) => filter === "all" || item.category === filter),
    [filter],
  );

  /** Only real photos are navigable in the lightbox. */
  const photos = useMemo(
    () => visible.filter((item): item is Photo => item.kind === "photo"),
    [visible],
  );

  const open = lightboxIndex !== null;
  const current = open ? photos[lightboxIndex] : undefined;

  const step = (delta: number) => {
    setLightboxIndex((index) => {
      if (index === null || photos.length === 0) return index;
      return (index + delta + photos.length) % photos.length;
    });
  };

  const closeLightbox = () => {
    setLightboxIndex(null);
    lastFocused.current?.focus();
  };

  // Filtering can shrink the photo list out from under an open lightbox.
  useEffect(() => {
    if (lightboxIndex !== null && lightboxIndex >= photos.length) setLightboxIndex(null);
  }, [photos.length, lightboxIndex]);

  useEffect(() => {
    if (!open) return;

    document.body.classList.add("is-locked");
    closeButtonRef.current?.focus();

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeLightbox();
      else if (event.key === "ArrowLeft") step(-1);
      else if (event.key === "ArrowRight") step(1);
    };

    window.addEventListener("keydown", onKeyDown);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      document.body.classList.remove("is-locked");
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, photos.length]);

  return (
    <section id="gallery" className="py-19 md:py-26">
      <div className="mx-auto max-w-[1180px] px-6">
        <Reveal>
          <Eyebrow>Inside the clinic</Eyebrow>
          <h2 className="text-[clamp(2rem,4vw,3.1rem)]">
            Have a look around
            <br />
            before you walk in.
          </h2>
          <Lede>
            The room, the kit and the people you&rsquo;ll actually meet. No stock photos of someone
            else&rsquo;s practice.
          </Lede>
        </Reveal>

        <Reveal delay={1}>
          <div
            role="group"
            aria-label="Filter gallery"
            className="mb-7 mt-9 flex flex-wrap gap-2.5"
          >
            {GALLERY_FILTERS.map((option) => {
              const pressed = filter === option.value;
              return (
                <button
                  key={option.value}
                  type="button"
                  aria-pressed={pressed}
                  onClick={() => setFilter(option.value)}
                  className={cn(
                    "cursor-pointer rounded-full border-[1.5px] px-5 py-2.5 text-[0.88rem] font-semibold transition-colors duration-200",
                    pressed
                      ? "border-theatre bg-theatre text-white"
                      : "border-border bg-white text-muted-foreground hover:border-theatre hover:text-foreground",
                  )}
                >
                  {option.label}
                </button>
              );
            })}
          </div>
        </Reveal>

        <div className="columns-1 gap-[18px] md:columns-2 lg:columns-3">
          {visible.map((item) => {
            if (item.kind === "slot") {
              return (
                <div
                  key={`${item.title}-${item.category}`}
                  className="mb-[18px] grid aspect-[4/5] break-inside-avoid place-items-center rounded-lg border-[1.5px] border-dashed border-border bg-white p-[26px] text-center"
                >
                  <span className="font-mono text-[0.68rem] uppercase leading-[1.9] tracking-[0.14em] text-muted-foreground">
                    <span className="mb-1.5 block font-sans text-base normal-case tracking-normal text-foreground">
                      {item.title}
                    </span>
                    Photo slot
                    <br />
                    {item.note}
                  </span>
                </div>
              );
            }

            const photoIndex = photos.indexOf(item);
            return (
              <button
                key={item.src}
                type="button"
                aria-label={`View larger: ${item.caption}`}
                onClick={(event) => {
                  lastFocused.current = event.currentTarget;
                  setLightboxIndex(photoIndex);
                }}
                className="group relative mb-[18px] block w-full cursor-zoom-in break-inside-avoid overflow-hidden rounded-lg bg-mint"
              >
                <img
                  src={item.src}
                  alt={item.caption}
                  loading="lazy"
                  className="block h-auto w-full transition-transform duration-[550ms] ease-brand group-hover:scale-[1.06]"
                />
                <span className="pointer-events-none absolute inset-x-0 bottom-0 translate-y-2.5 bg-gradient-to-t from-ink/85 to-transparent px-[18px] pb-[15px] pt-[34px] text-left text-[0.86rem] font-semibold text-white opacity-0 transition duration-[350ms] ease-brand group-hover:translate-y-0 group-hover:opacity-100 group-focus-visible:translate-y-0 group-focus-visible:opacity-100">
                  {item.caption}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {open && current && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Gallery image viewer"
          onClick={(event) => {
            if (event.target === event.currentTarget) closeLightbox();
          }}
          onTouchStart={(event) => {
            touchStartX.current = event.changedTouches[0].clientX;
          }}
          onTouchEnd={(event) => {
            const delta = event.changedTouches[0].clientX - touchStartX.current;
            if (Math.abs(delta) > 55) step(delta < 0 ? 1 : -1);
          }}
          className="fixed inset-0 z-100 flex items-center justify-center bg-ink/95 px-3 pb-[84px] pt-[66px] md:px-5 md:pb-[92px] md:pt-[76px]"
        >
          <button
            ref={closeButtonRef}
            type="button"
            aria-label="Close viewer"
            onClick={closeLightbox}
            className="absolute right-5 top-5 grid size-[46px] cursor-pointer place-items-center rounded-full bg-white/[0.12] text-white transition hover:scale-105 hover:bg-white/[0.26]"
          >
            <X className="size-5" />
          </button>

          {photos.length > 1 && (
            <>
              <button
                type="button"
                aria-label="Previous image"
                onClick={() => step(-1)}
                className="absolute left-2.5 top-1/2 grid size-[46px] -translate-y-1/2 cursor-pointer place-items-center rounded-full bg-white/[0.12] text-white transition hover:scale-105 hover:bg-white/[0.26] md:left-5"
              >
                <ChevronLeft className="size-5" />
              </button>
              <button
                type="button"
                aria-label="Next image"
                onClick={() => step(1)}
                className="absolute right-2.5 top-1/2 grid size-[46px] -translate-y-1/2 cursor-pointer place-items-center rounded-full bg-white/[0.12] text-white transition hover:scale-105 hover:bg-white/[0.26] md:right-5"
              >
                <ChevronRight className="size-5" />
              </button>
            </>
          )}

          <img
            src={current.src}
            alt={current.caption}
            className="max-h-full max-w-full rounded-xl object-contain shadow-[0_30px_70px_-20px_rgb(0_0_0/0.7)]"
          />

          <p className="absolute inset-x-0 bottom-[34px] px-6 text-center text-[0.95rem] font-medium text-white">
            <span className="block font-mono text-[0.7rem] uppercase tracking-[0.14em] text-white/50">
              {lightboxIndex + 1} of {photos.length}
            </span>
            {current.caption}
          </p>
        </div>
      )}
    </section>
  );
}
