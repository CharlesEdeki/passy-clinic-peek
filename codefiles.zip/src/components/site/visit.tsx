import { MapPin } from "lucide-react";

import clinicMap from "@/assets/clinic-map.jpg";
import { Eyebrow, Lede, Reveal } from "@/components/site/primitives";
import { useClinicStatus } from "@/hooks/use-clinic-status";
import { HOURS, MAPS_URL, PHONE_DISPLAY, PHONE_HREF } from "@/lib/clinic";
import { cn } from "@/lib/utils";

export function Visit() {
  const status = useClinicStatus();

  return (
    <section id="visit" className="py-19 md:py-26">
      <div className="mx-auto grid max-w-[1180px] items-center gap-11 px-6 lg:grid-cols-2 lg:gap-14">
        <Reveal>
          <Eyebrow>Visit us</Eyebrow>
          <h2 className="text-[clamp(2rem,4vw,3.1rem)]">Jakande Gate, Isolo.</h2>
          <Lede>
            Easy to reach from Ejigbo, Okota, Ago Palace and Mushin. Parking available on site.
          </Lede>

          <ul className="mt-6.5">
            {HOURS.map(([day, hours], index) => (
              <li
                key={day}
                className={cn(
                  "flex justify-between border-b border-border py-3 text-[0.95rem]",
                  status?.day === index && "font-bold text-theatre",
                )}
              >
                <span>{day}</span>
                <span>{hours}</span>
              </li>
            ))}
          </ul>

          <div className="mt-7 flex flex-wrap gap-3.5">
            <a
              href={PHONE_HREF}
              className="inline-flex items-center gap-2.5 rounded-full bg-theatre px-[26px] py-3.5 text-[0.97rem] font-semibold text-white shadow-[0_6px_20px_-8px_rgb(31_94_78/0.7)] transition-[transform,background-color] duration-200 hover:-translate-y-0.5 hover:bg-theatre-deep"
            >
              {PHONE_DISPLAY}
            </a>
            <a
              href={MAPS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2.5 rounded-full border-[1.5px] border-border px-[26px] py-3.5 text-[0.97rem] font-semibold transition-[transform,border-color,background-color] duration-200 hover:-translate-y-0.5 hover:border-theatre hover:bg-white"
            >
              Get directions
            </a>
          </div>
        </Reveal>

        <Reveal delay={1}>
          <div className="relative aspect-[4/3] overflow-hidden rounded-lg border border-border bg-mint">
            <img
              src={clinicMap}
              alt="Map showing Passy Dental Clinic at Jakande Gate, Isolo"
              loading="lazy"
              className="size-full object-cover"
            />
            <a
              href={MAPS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="absolute inset-x-4 bottom-4 flex items-center gap-3.5 rounded-[14px] bg-white/95 px-[18px] py-3.5 transition-transform duration-200 hover:-translate-y-0.5"
            >
              <span className="grid size-[38px] shrink-0 place-items-center rounded-full bg-coral">
                <MapPin className="size-[19px] text-white" strokeWidth={2} aria-hidden="true" />
              </span>
              <span className="text-left">
                <b className="block text-[0.92rem]">Passy Dental Clinic</b>
                <span className="text-[0.8rem] text-muted-foreground">
                  Jakande Gate, Isolo · Open in Maps
                </span>
              </span>
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
