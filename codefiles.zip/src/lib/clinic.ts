/**
 * Single source of truth for clinic content.
 * Anything that appears in more than one place on the page lives here.
 */

export const WHATSAPP_NUMBER = "2347067164269";
export const PHONE_DISPLAY = "+234 706 716 4269";
export const PHONE_HREF = "tel:+2347067164269";
export const EMAIL = "hello@passydentalclinic.com";
export const MAPS_URL = "https://maps.google.com/?q=Jakande+Gate+Isolo+Lagos";
export const ADDRESS_LINES = [
  "Crystall Computer & Shopping Mall,",
  "Jakande Gate Bus-stop, Isheri Oshun Rd,",
  "Isolo, Lagos 102214, Nigeria.",
];

export function whatsappLink(message: string) {
  return `https://api.whatsapp.com/send?phone=${WHATSAPP_NUMBER}&text=${encodeURIComponent(message)}`;
}

export type Service = {
  title: string;
  blurb: string;
  /** Single path drawn as a stroked 24x24 icon. */
  icon: string;
};

export const SERVICES: Service[] = [
  {
    title: "General Dentistry",
    blurb: "Comprehensive routine care for patients of all ages.",
    icon: "M12 2C9 2 8 4 5 4S1 7 1 11c0 5 2 7 3 10s1 1 2 1 1-5 2-8 2-3 4-3 3 0 4 3 1 8 2 8 1 2 2-1 3-5 3-10c0-4-1-7-4-7s-4-2-7-2z",
  },
  {
    title: "Orthodontics",
    blurb: "Braces and aligners to correct bite issues and straighten teeth.",
    icon: "M3 8h18M3 16h18M7 8v8M12 8v8M17 8v8",
  },
  {
    title: "Cosmetic Dentistry",
    blurb: "Whitening, veneers and smile makeovers.",
    icon: "M12 3l2.2 5.5L20 9.7l-4 4.2 1 6.1-5-3-5 3 1-6.1-4-4.2 5.8-1.2z",
  },
  {
    title: "Preventive Care",
    blurb: "Cleaning, scaling and education that keeps problems away.",
    icon: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z",
  },
  {
    title: "Pediatric Care",
    blurb: "Dentistry for children in a friendly, fear-free setting.",
    icon: "M12 21s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.5-7 10-7 10z",
  },
  {
    title: "Emergency Services",
    blurb: "Urgent care for pain, trauma or a knocked-out tooth.",
    icon: "M13 2L4 14h6l-1 8 9-12h-6z",
  },
  {
    title: "Sedation Dentistry",
    blurb: "Calm, comfortable treatment for anxious patients.",
    icon: "M12 3a9 9 0 1 0 9 9 7 7 0 0 1-9-9z",
  },
  {
    title: "Implants & Prosthetics",
    blurb: "Replace missing teeth with stable, natural-looking results.",
    icon: "M12 2v20M8 6h8M9 11h6M10 16h4",
  },
  {
    title: "Root Canal Treatment",
    blurb: "Relieve infection and save the natural tooth.",
    icon: "M12 2C8 2 6 5 6 9c0 5 3 6 4 13h4c1-7 4-8 4-13 0-4-2-7-6-7z",
  },
];

export type Review = { name: string; area: string; quote: string };

export const REVIEWS: Review[] = [
  {
    name: "Chinelo A.",
    area: "Ejigbo",
    quote:
      "My son actually asked when we're going back. That has never happened at a dentist before.",
  },
  {
    name: "Tunde B.",
    area: "Okota",
    quote:
      "Came in on a Saturday with a cracked molar. Seen within the hour, no drama, no inflated bill.",
  },
  {
    name: "Amaka O.",
    area: "Isolo",
    quote:
      "They checked my HMO cover before starting, so I knew exactly what I'd pay. Refreshing.",
  },
];

export type Faq = { question: string; answer: string };

export const FAQS: Faq[] = [
  {
    question: "Do I need an appointment, or can I walk in?",
    answer:
      "Walk-ins are welcome and we keep slots free for pain each day. Booking ahead simply means less waiting — send your details on WhatsApp and we'll confirm a time.",
  },
  {
    question: "Which HMOs do you accept?",
    answer:
      "We currently work with Grooming Health HMO and Reliance HMO. Bring your enrolee ID and we'll verify your cover before any treatment starts, so nothing comes as a surprise.",
  },
  {
    question: "My child is terrified of the dentist. What happens?",
    answer:
      "Nothing they haven't agreed to. The first visit is usually just a look, a count of the teeth and a ride in the chair. We move at the child's pace and explain each step before it happens.",
  },
  {
    question: "How much does a scaling and polishing cost?",
    answer:
      "Prices depend on how much build-up there is, so we quote after looking. Ask on WhatsApp and we'll give you a realistic range before you travel.",
  },
  {
    question: "Do you treat emergencies outside opening hours?",
    answer:
      "Call the clinic line first. For genuine emergencies we'll advise you immediately and, where needed, arrange to see you as early as possible the next working day.",
  },
];

/** Indexed by JS day number, Sunday first. */
export const HOURS: ReadonlyArray<readonly [string, string]> = [
  ["Sunday", "Closed"],
  ["Monday", "8:00am – 6:00pm"],
  ["Tuesday", "8:00am – 6:00pm"],
  ["Wednesday", "8:00am – 6:00pm"],
  ["Thursday", "8:00am – 6:00pm"],
  ["Friday", "8:00am – 6:00pm"],
  ["Saturday", "8:00am – 6:00pm"],
];

export const OPENS_MINUTES = 8 * 60;
export const CLOSES_MINUTES = 18 * 60;

export const HMO_PARTNERS = ["Grooming Health HMO", "Reliance HMO", "Pay as you go"];

export const NAV_LINKS = [
  { href: "#services", label: "Services" },
  { href: "#reviews", label: "Reviews" },
  { href: "#gallery", label: "Gallery" },
  { href: "#results", label: "Results" },
  { href: "#hmo", label: "HMO" },
  { href: "#faq", label: "Questions" },
  { href: "#visit", label: "Visit" },
];

export type GalleryCategory = "clinic" | "team" | "equipment";

export const GALLERY_FILTERS: ReadonlyArray<{
  value: GalleryCategory | "all";
  label: string;
}> = [
  { value: "all", label: "Everything" },
  { value: "clinic", label: "The clinic" },
  { value: "team", label: "Our team" },
  { value: "equipment", label: "Equipment" },
];

/** Before/after pairs. Drop consented photos into public/images/ to light these up. */
export type CaseStudy = { id: string; title: string; meta: string };

export const CASES: CaseStudy[] = [
  { id: "case-1", title: "Composite bonding, upper four", meta: "Two visits · 2024" },
  { id: "case-2", title: "Professional whitening", meta: "Single session · 2025" },
  { id: "case-3", title: "Fixed braces, 14 months", meta: "Orthodontics · 2023–2024" },
  { id: "case-4", title: "Scaling and polishing", meta: "One visit · 2025" },
];
